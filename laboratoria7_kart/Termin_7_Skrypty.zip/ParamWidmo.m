% ############################################################
% ################### PARAMETRYCZNE METODY ESTYMACJI WIDMA
clear;
fp = 100;          % czestotliwo�� pr�bkowania
N = 50;            % d�ugo�� sugna�u 
%N = 200;
%N = 1000;
[x,tx] = sygnTestEstymWidma (fp, N);
subplot (221);
plot (tx ,x);
xlabel ('czas [s]');
ylabel ('sygnal');

% ------------- periodogram
Nf = 2^13;
N21 = Nf/2 + 1;
p = 6;             %  d�ugo�� filtru prognozuj�cego
p = 12;
p = 24;
[Pxx1, f] = pcov (x, p, Nf, fp);
subplot (222);
semilogy (f, Pxx1(1:N21));
ylim ([0.0001 100]);
xlabel ('czest [Hz]');
ylabel ('widm.gest.mocy');

% ------------- periodogram z oknem - widmo Cooleya
[Pxx2, f] = pburg (x, p, Nf, fp);
subplot (223);
semilogy (f, Pxx2(1:N21));
ylim ([0.0001 100]);
xlabel ('czest [Hz]');
ylabel ('widm.gest.mocy');

% ------------- wgm z definicji
[Pxx3, f] = pyulear (x, p, Nf, fp);
subplot (224);
semilogy (f, Pxx3(1:N21));
ylim ([0.0001 100]);
xlabel ('czest [Hz]');
ylabel ('widm.gest.mocy');

set (gcf,'Position',[50 50 800 700]);